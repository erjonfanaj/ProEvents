﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PizzaTime.Models;
using RealEstateCMS.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaTime.Controllers {
    public class HomeController : Controller {
        private readonly ILogger<HomeController> _logger;

        private readonly AppDbContext _context;

        private User ActiveUser { get; set; }
        public User activeuser {
            get { return _context.Users.Where(u => u.ID == HttpContext.Session.GetInt32("UserId")).FirstOrDefault(); }
        }

        public HomeController(ILogger<HomeController> logger, AppDbContext context) {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index() {
            ViewBag.ActiveUser = activeuser;

            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Login", "User");
            }
            ViewBag.Msg = null;
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            return View();
        }

        [HttpGet("Order")]
        public IActionResult Create() {
            ViewBag.ActiveUser = activeuser;
            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Login", "User");
            }
            ViewBag.Pizza = _context.Pizzas.ToList();
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            return View();
        }

        [HttpGet("Favorite")]
        public IActionResult FavoriteOrder() {
            ViewBag.ActiveUser = activeuser;
            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Login", "User");
            }
            ViewBag.Pizza = _context.Pizzas.ToList();
            var favPizza = _context.Orders.Where(o => o.UserID == activeuser.ID).Include(p => p.Pizza).ToList();
            ViewBag.FavPizza = favPizza.Where(p => p.Favorite == true).FirstOrDefault();
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            if (ViewBag.FavPizza == null) {
                ViewBag.Msg = "You don't a favorite pizza!";
                ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
                return View("Index");
            }

            return View("FavoriteOrder");
        }

        [HttpPost("Order/Check")]
        public IActionResult CheckOrder(OrderModel orderModel) {
            ModelState.Remove("Price");
            if (ModelState.IsValid) {
                return RedirectToAction("Details", orderModel);
            }
            ViewBag.Pizza = _context.Pizzas.ToList();
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            return View("Create");
        }

        [HttpPost("Order/Create")]
        public IActionResult CreateOrder(OrderModel orderModel) {
            if (ModelState.IsValid) {
                Order order = new Order() {
                    Method = orderModel.Method,
                    Size = orderModel.Size,
                    Crust = orderModel.Crust,
                    Quantity = orderModel.Quantity,
                    PizzaID = _context.Pizzas.FirstOrDefault(p => p.ID == orderModel.Pizza).ID,
                    UserID = activeuser.ID,
                    Favorite = false,
                    Active = true,
                };
                switch (orderModel.Size) {
                    case "Small":
                        order.Price = 7.99 * order.Quantity;
                        break;
                    case "Medium":
                        order.Price = 9.99 * order.Quantity;
                        break;
                    case "Large":
                        order.Price = 12.99 * order.Quantity;
                        break;
                    case "Extra Large":
                        order.Price = 15.99 * order.Quantity;
                        break;
                }
                _context.Orders.Add(order);
                _context.SaveChanges();

                var lastOrder = _context.Orders.OrderBy(o => o.UpdatedAt).First();
                ViewBag.ActiveUser = activeuser;
                ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
                return RedirectToAction("Details", orderModel);
            }
            return View("Create");
        }

        [HttpPost("/purchase")]
        public IActionResult Purchase(OrderModel orderModel) {
            var order = _context.Orders.FirstOrDefault(o => o.UserID == activeuser.ID
                                                && o.Method == orderModel.Method
                                                && o.PizzaID == orderModel.Pizza
                                                && o.Price == orderModel.Price
                                                && o.Quantity == orderModel.Quantity
                                                && o.Crust == orderModel.Crust
                                                && o.Active == true);
            order.Active = false;
            _context.Update(order);
            _context.SaveChanges();
            return RedirectToAction("ActiveOrders");
        }

        [HttpGet("/Order/Details")]
        public IActionResult Details(OrderModel orderModel) {
            ViewBag.ActiveUser = activeuser;
            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Index");
            }

            ViewBag.Order = orderModel;
            var pizza = _context.Pizzas.FirstOrDefault(p => p.ID == orderModel.Pizza);
            ViewBag.Pizza = pizza;
            var price = 0.00;
            switch (orderModel.Size) {
                case "Small":
                    price = 7.99;
                    break;
                case "Medium":
                    price = 9.99;
                    break;
                case "Large":
                    price = 12.99;
                    break;
                case "Extra Large":
                    price = 15.99;
                    break;
            }
            ViewBag.Price = price;
            ViewBag.PriceQty = price * orderModel.Quantity;
            ViewBag.ActiveUser = activeuser;
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            return View();
        }

        [HttpGet("/Order/Detail")]
        public IActionResult DetailsID(int id) {
            ViewBag.ActiveUser = activeuser;
            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Index");
            }
            var order = _context.Orders.FirstOrDefault(o => o.ID == id);
            OrderModel orderModel = new OrderModel() {
                Crust = order.Crust,
                Method = order.Method,
                Pizza = order.PizzaID,
                Price = order.Price,
                Quantity = order.Quantity,
                Size = order.Size
            };
            ViewBag.Order = orderModel;
            var pizza = _context.Pizzas.FirstOrDefault(p => p.ID == orderModel.Pizza);
            ViewBag.Pizza = pizza;
            var price = 0.00;
            switch (orderModel.Size) {
                case "Small":
                    price = 7.99;
                    break;
                case "Medium":
                    price = 9.99;
                    break;
                case "Large":
                    price = 12.99;
                    break;
                case "Extra Large":
                    price = 15.99;
                    break;
            }
            ViewBag.Price = price;
            ViewBag.PriceQty = price * orderModel.Quantity;
            ViewBag.ActiveUser = activeuser;
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            return View("Details");
        }

        [HttpGet("Orders")]
        public IActionResult ActiveOrders() {
            ViewBag.ActiveUser = activeuser;
            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Index");
            }
            var allOrders = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList();
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true)
                                                .Include(o => o.Pizza).ToList().Count;
            var allOrderModel = new List<OrderListModel>();
            foreach (var item in allOrders) {
                OrderListModel order = new OrderListModel() {
                    ID = item.ID,
                    Crust = item.Crust,
                    Method = item.Method,
                    Pizza = item.Pizza,
                    Price = item.Price,
                    Quantity = item.Quantity,
                    Size = item.Size
                };
                allOrderModel.Add(order);
            }
            return View("AllOrders", allOrderModel);
        }

        [HttpGet("/Surprise")]
        public IActionResult Surprise() {
            ViewBag.ActiveUser = activeuser;
            if (ViewBag.ActiveUser == null) {
                return RedirectToAction("Login", "User");
            }
            ViewBag.Pizza = _context.Pizzas.ToList();
            ViewBag.OrdersNum = _context.Orders.Where(o => o.UserID == activeuser.ID && o.Active == true).ToList().Count;
            Random rnd = new Random();
            var allOrders = _context.Orders.ToArray();
            ViewBag.RandomOrder = allOrders[rnd.Next(0, allOrders.Length)];
            return View("Surprise");
        }

        public IActionResult Privacy() {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
