﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaTime.Models {
    public class State : BaseEntity {
        public string Code { get; set; }
    }
}
